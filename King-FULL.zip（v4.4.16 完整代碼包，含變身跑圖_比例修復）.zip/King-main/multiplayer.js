(function() {
  'use strict';

  // v2.4.0：Long-Poll 多人連線客戶端（零依賴，純 fetch）
  const STATUS = {
    OFFLINE: 'offline',
    LOADING: 'loading',
    CONNECTING: 'connecting',
    ONLINE: 'online',
    RECONNECTING: 'reconnecting',
    ERROR: 'error',
  };

  let status = STATUS.OFFLINE;
  let onStatusChange = null;
  let onChatMessage = null;
  let onMonsterDamage = null;
  let onMonsterKilled = null;
  let onGainReward = null;

  let serverUrl = '';
  let authToken = '';
  let myPlayerId = null;
  let currentMapId = null;
  // v4.4.8：客戶端分片重組緩衝區（伺服器對≥100字節消息分片，格式{t:'__c',c,i,n,d}）
  const clientChunkBuffers = new Map();
  let currentServerId = 'zeus';
  let currentCharIdx = 0;
  let currentWorldW = 2496;
  let currentWorldH = 1664;

  // v2.7.2：WebSocket 狀態
  let ws = null;
  let lastServerUrl = null; // v4.4.9：連接冪等，防止auth.js與_initCore重複連接競爭
  let wsConnected = false;
  let wsReconnectDelay = 1000;
  let wsReconnectTimer = null;
  let useWebSocket = false; // 是否成功切換到 WS

  let _wsFailureReason = ''; // v2.7.5：WS 上次失敗原因（供 UI 顯示）
  let _wsLastCloseCode = null; // v2.7.10：最後 close code
  let _wsLastCloseReason = ''; // v2.7.10：最後 close reason
  let _wsPath = '/'; // v2.7.10：伺服器 WS upgrade 路徑（從 /api/health 取得）

  function getWsFailureReason() { return _wsFailureReason; }
  function getWsLastCloseCode() { return _wsLastCloseCode; }
  function getWsLastCloseReason() { return _wsLastCloseReason; }
  // v2.7.10：回傳目前使用的傳輸層類型（'ws' | 'lp' | 'offline'）
  function getTransportType() {
    if (status === STATUS.OFFLINE || status === STATUS.ERROR) return 'offline';
    return useWebSocket ? 'ws' : 'lp';
  }

  const remotePlayers = new Map();
  // v4.4.0：伺服器端AI（Server Authoritative）
  const serverAIs = new Map();
  let pollAbortController = null;
  let pollRunning = false;
  let reconnectDelay = 1000;
  // v4.4.12：嚴禁離線遊戲——主動關閉標誌 + 斷線已回登入頁防重入
  let _manualClose = false;
  let _forcedBackToLogin = false;
  // 意外斷線：不重連、不降級、不進離線，立即清理並回登入頁
  function _forceBackToLogin(reason) {
    if (_forcedBackToLogin || _manualClose) return;
    _forcedBackToLogin = true;
    try { if (wsReconnectTimer) { clearTimeout(wsReconnectTimer); wsReconnectTimer = null; } } catch(e) {}
    try { setStatus(STATUS.OFFLINE); } catch(e) {}
    try { if (typeof window.setOfflineMode === 'function') window.setOfflineMode(false); } catch(e) {}
    console.error('[GAME-WS] 連線中斷，立即返回登入頁：', reason);
    try { window.alert('與伺服器連線中斷，即將返回登入頁。\n原因：' + (reason || '網路斷線')); } catch(e) {}
    try { localStorage.removeItem('mmo_keep_session'); } catch(e) {}
    try { if (typeof window.location !== 'undefined') window.location.reload(); } catch(e) {}
  }
  let lastPollTime = 0;
  let lastUpdateTime = 0;
  const UPDATE_THROTTLE = 100; // v2.7.5：50ms → 100ms（10Hz），降低廣播頻寬

  // ========== 工具 ==========
  function getAuthHeader() {
    return { 'Authorization': 'Bearer ' + authToken };
  }

  function apiPost(path, body) {
    return fetch(serverUrl + path, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      credentials: 'omit',
      body: JSON.stringify(body || {}),
    }).then(r => r.json());
  }

  function apiGet(path) {
    return fetch(serverUrl + path, {
      method: 'GET',
      headers: getAuthHeader(),
      credentials: 'omit',
    }).then(r => r.json());
  }

  function setStatus(newStatus) {
    if (status === newStatus) return;
    status = newStatus;
    if (onStatusChange) {
      try { onStatusChange(status); } catch (e) { console.error('[Multi] status cb error:', e); }
    }
  }

  // 座標轉換（與原 socket.io 版一致）
  function serverToWorld(sx, sy) {
    return { x: sx, y: sy };
  }
  function worldToServer(wx, wy) {
    return { x: wx, y: wy };
  }

  // ========== 公開 API ==========
  const MultiplayerClient = {
    get status() { return status; },
    get myId() { return myPlayerId; },
    get connected() { return status === STATUS.ONLINE; },
    get serverId() { return currentServerId; },
    get mapId() { return currentMapId; },
    get transport() { return useWebSocket ? 'websocket' : (status === STATUS.ONLINE ? 'longpoll' : 'offline'); },
    get wsFailureReason() { return _wsFailureReason || ''; },
    get wsLastCloseCode() { return _wsLastCloseCode || null; },
    get wsLastCloseReason() { return _wsLastCloseReason || ''; },
    get serverId() { return currentServerId || null; },
    get mapId() { return currentMapId || null; },
    STATUS: STATUS,

    getSavedServerUrl() {
      try { return localStorage.getItem('mp_server_url') || ''; } catch (e) { return ''; }
    },
    saveServerUrl(url) {
      try { localStorage.setItem('mp_server_url', url || ''); } catch (e) { /* ignore */ }
    },

    setStatusCallback(cb) { onStatusChange = typeof cb === 'function' ? cb : null; },
    setChatCallback(cb) { onChatMessage = typeof cb === 'function' ? cb : null; },
    setMonsterDamageCallback(cb) { onMonsterDamage = typeof cb === 'function' ? cb : null; },
    setMonsterKilledCallback(cb) { onMonsterKilled = typeof cb === 'function' ? cb : null; },
    setGainRewardCallback(cb) { onGainReward = typeof cb === 'function' ? cb : null; },

    setWorldSize(w, h) {
      currentWorldW = w || 2496;
      currentWorldH = h || 1664;
    },

    // 連線：token 從遊戲端傳入（與 cookie 同步）
     connect(url, token) {
       const u = (url || '').trim();
       if (!u) {
         setStatus(STATUS.ERROR);
         return Promise.reject(new Error('伺服器位址為空'));
       }
       serverUrl = u.replace(/\/+$/, '');
       MultiplayerClient.saveServerUrl(u);
       authToken = token || '';

       // v4.4.9 冪等：同一URL已有WS在連接/在線，直接複用，不再關閉重建（消除雙連接競爭）
       if (lastServerUrl === serverUrl && ws && (ws.readyState === 0 || ws.readyState === 1)
           && (status === STATUS.CONNECTING || status === STATUS.ONLINE || status === STATUS.RECONNECTING)) {
         console.log('[GAME-WS] 同一伺服器連線已存在(' + status + ')，複用，不重複連接');
         return Promise.resolve();
       }
       lastServerUrl = serverUrl;

       console.log('[GAME-WS] ===== MultiplayerClient.connect() 被呼叫 =====');
       console.log('[GAME-WS]   serverUrl =', serverUrl);
       console.log('[GAME-WS]   token 長度 =', authToken ? authToken.length : 0);

       // 先斷開舊的
      if (pollAbortController) {
        try { pollAbortController.abort(); } catch(e) {}
        pollAbortController = null;
      }
      if (ws) {
        try { ws.close(); } catch(e) {}
        ws = null;
        wsConnected = false;
      }
      clearAllRemotePlayers();
      myPlayerId = null;
      reconnectDelay = 1000;
      wsReconnectDelay = 1000;
      useWebSocket = false;
      setStatus(STATUS.CONNECTING);

       // 用 health 檢查伺服器是否活著，並決定是否用 WS
       // v3.1.2：即使 health 失敗也嘗試 WS（有些平台 proxy 會擋 /api/health 但 WS upgrade 正常）
       return fetch(serverUrl + '/api/health')
         .then(r => r.json())
         .then(data => {
           if (data && data.status === 'online') {
             setStatus(STATUS.ONLINE);
             console.info('[Multi] 伺服器連線成功:', data.version, 'WS=', data.webSocket || data.socketIo);
             // v2.7.10：從伺服器取得 WS upgrade 路徑（預設 '/'）
             _wsPath = data.wsTransportPath || '/';

             // v2.7.7：伺服器在線就先把 AI 模式切到 server（防止本地 AI 偷生）
             if (typeof window.setServerOnline === 'function') {
               window.setServerOnline(currentServerId || 'pending', null);
             }
             if (typeof window.setOfflineMode === 'function') {
               window.setOfflineMode(false);
             }

             // v2.7.2：若伺服器支援 WebSocket，優先連 WS（失敗自動 fallback long-poll）
             // v3.1.2：health 有 webSocket 才連；沒有的話直接 LP
             if (data.webSocket || data.socketIo) {
               _startWsWithRetry();
             } else {
               _wsFailureReason = '伺服器未啟用 WebSocket';
               startPollLoop();
             }
           } else {
             // health 回來但 status 不是 online → 仍嘗試 WS + LP
             console.warn('[Multi] health 回應異常，仍嘗試 WS 連線');
             _startWsWithRetry();
             startPollLoop();
           }
           // v4.4.9：純WS模式不在此走HTTP /api/mp/join（依賴DB易失敗）；join由auth_ok後_wsAutoJoinWhenReady統一處理
           _wsAutoJoinWhenReady();
           return null;
         })
         .catch(err => {
           // v3.1.2：health fetch 失敗（可能被 proxy 擋）也不要放棄 — 仍嘗試 WS + LP
           console.warn('[Multi] /api/health 失敗:', err.message, '仍嘗試 WS 連線');
           setStatus(STATUS.CONNECTING);
           _updateWsBadge('connecting', 'WS連線中');
           _startWsWithRetry();
           // v4.4.9：純WS，不走HTTP joinWorld；auth_ok後自動join
           _wsAutoJoinWhenReady();
           return null;
         });
     },


    disconnect() {
      _manualClose = true; // v4.4.12：主動斷線，不觸發「意外斷線回登入頁」
      if (currentMapId) {
        try {
          if (ws && wsConnected) {
            wsSend({ type: 'leave_map' });
          } else {
            apiPost('/api/mp/leave', { mapId: currentMapId, charIdx: currentCharIdx });
          }
        } catch(e) {}
      }
      if (pollAbortController) {
        try { pollAbortController.abort(); } catch(e) {}
        pollAbortController = null;
      }
      pollRunning = false;
      if (ws) {
        try { ws.close(); } catch(e) {}
        ws = null;
        wsConnected = false;
      }
      if (wsReconnectTimer) {
        clearTimeout(wsReconnectTimer);
        wsReconnectTimer = null;
      }
      clearAllRemotePlayers();
      myPlayerId = null;
      currentMapId = null;
      useWebSocket = false;
      setStatus(STATUS.OFFLINE);
    },

    // 加入世界（從 auth token 推斷帳號）
    // 加入世界（從 auth token 推斷帳號）
    joinWorld(opts) {
      opts = opts || {};
      currentCharIdx = opts.charIdx ?? (window.GS.currentCharIdx ?? 0);
      const mapId = opts.mapId || window.GS.currentMap || 'village';
      // v2.7.3：優先從 opts 取，其次用已選伺服器（AuthSystem），最後才 fallback zeus
      let serverId = opts.serverId;
      if (!serverId && typeof AuthSystem !== 'undefined' && AuthSystem.getCurrentServer) {
        const srv = AuthSystem.getCurrentServer();
        if (srv && srv.id) serverId = srv.id;
      }
      if (!serverId && window.GS.currentServerId) serverId = window.GS.currentServerId;
      if (!serverId) serverId = currentServerId || 'zeus';
      currentServerId = serverId;
      // 在線模式先告訴 game.js 進入在線狀態，避免本地隨機生成 AI
      if (typeof window.setServerOnline === 'function') {
        window.setServerOnline(serverId, mapId);
      }
      return apiPost('/api/mp/join', {
        mapId,
        serverId,
        charIdx: currentCharIdx,
      }).then(data => {
        if (data.ok) {
          myPlayerId = data.playerId;
          currentMapId = mapId;
          currentServerId = serverId;
          // 初始化遠端玩家列表
          if (data.others && Array.isArray(data.others)) {
            data.others.forEach(p => {
              if (p.playerId !== myPlayerId) {
                addOrUpdateRemotePlayer({
                  id: p.playerId,
                  name: p.name,
                  class: p.classId,
                  level: p.level,
                  x: p.x, y: p.y, dir: p.dir,
                  transform: p.transformId,
                });
              }
            });
          }
          // v2.7.3：同步伺服器級 AI 列表（權威）—— 收到才標記在線
          if (typeof window.setServerAIs === 'function') {
            window.setServerAIs((data.ais && Array.isArray(data.ais)) ? data.ais : [], serverId, mapId);
          }
          // v2.7.3：回傳 instanceId 給客戶端診斷用
          if (data.instanceId && typeof window._setServerInstanceId === 'function') {
            window._setServerInstanceId(data.instanceId);
          }
          setStatus(STATUS.ONLINE);
          // v2.7.2：WS 模式下不啟動 long-poll（WS 已處理所有事件）
          if (!useWebSocket) {
            startPollLoop();
          }
           // v3.1.1：WS 連上後，若已 joinWorld 完成（有 myPlayerId），立即發 join_map
           //  修復：WS auth 比 LP join 慢時，auth_ok 後不會自動 join_map 的 bug
           if (ws && wsConnected) {
             wsSend({
               type: 'join_map',
               serverId,
               mapId,
               playerId: myPlayerId,
               name: window.GS.player?.name || 'Player',
               classId: window.GS.player?.classId || 'warrior',
               level: window.GS.player?.level || 1,
               charIdx: currentCharIdx,
               x: window.GS.player?.x,
               y: window.GS.player?.y,
               hp: window.GS.player?.hp,
               maxHp: window.GS.player?.hpMax,
               mp: window.GS.player?.mp,
               maxMp: window.GS.player?.mpMax,
               nation: window.GS.player?.nation || '',
             });
             console.log('[Multi] WS join_map 已發送 (LP join 完成後)');
           }
          console.info('[Multi] 加入地圖 ' + mapId + '，在線 ' + ((data.others||[]).length+1) + ' 人');
          return data;
        } else {
          throw new Error(data.error || '加入失敗');
        }
        }).catch(err => {
         console.warn('[Multi] joinWorld 失敗:', err.message);
         // v2.8.2：join 失敗時標記離線，避免 health 成功但 join 失敗導致狀態假 ON
         if (typeof window.setOfflineMode === 'function') window.setOfflineMode(true);
         return null;
       });
    },

    // 切換地圖
    enterMap(mapId, charIdx, worldW, worldH) {
      if (!mapId || mapId === currentMapId) return Promise.resolve();
      // 先離開舊地圖
      const oldMap = currentMapId;
      currentMapId = mapId;
      if (worldW) currentWorldW = worldW;
      if (worldH) currentWorldH = worldH;
      if (charIdx != null) currentCharIdx = charIdx;

      // 清空遠端玩家
      clearAllRemotePlayers();

      // 加入新地圖（v2.7.3：serverId 用當前伺服器，不再寫死 zeus）
      const sId = currentServerId || (typeof AuthSystem !== 'undefined' && AuthSystem.getCurrentServer && AuthSystem.getCurrentServer()?.id) || 'zeus';
      return apiPost('/api/mp/join', {
        mapId,
        serverId: sId,
        charIdx: currentCharIdx,
      }).then(data => {
        if (data.ok) {
          myPlayerId = data.playerId;
          if (data.others && Array.isArray(data.others)) {
            data.others.forEach(p => {
              if (p.playerId !== myPlayerId) {
                addOrUpdateRemotePlayer({
                  id: p.playerId,
                  name: p.name,
                  class: p.classId,
                  level: p.level,
                  x: p.x, y: p.y, dir: p.dir,
                  transform: p.transformId,
                });
              }
            });
          }
          console.info('[Multi] 進入地圖 ' + mapId);
          return data;
        }
        return null;
      }).catch(() => null);
    },

    // 回報移動（節流）
    reportMove(x, y, dir) {
      if (status !== STATUS.ONLINE || !currentMapId) return;
      const now = Date.now();
      if (now - lastUpdateTime < UPDATE_THROTTLE) return;
      lastUpdateTime = now;
      const sPos = worldToServer(x, y);
      // v2.7.2：優先走 WebSocket
      if (useWebSocket && ws && wsConnected) {
        wsSend({
          type: 'move',
          x: sPos.x, y: sPos.y, dir: dir,
        });
      } else {
        apiPost('/api/mp/update', {
          mapId: currentMapId,
          charIdx: currentCharIdx,
          x: sPos.x,
          y: sPos.y,
          dir: dir,
        }).catch(() => {
          // 失敗不影響
        });
      }
    },

    // 回報血量變化
    reportHp(hp, maxHp) {
      if (status !== STATUS.ONLINE || !currentMapId) return;
      if (useWebSocket && ws && wsConnected) {
        wsSend({ type: 'hp', hp, maxHp });
      } else {
        apiPost('/api/mp/update', {
          mapId: currentMapId,
          charIdx: currentCharIdx,
          hp, maxHp,
        }).catch(() => {});
      }
    },

    // 回報變身變化
    reportTransform(transformId) {
      if (status !== STATUS.ONLINE || !currentMapId) return;
      if (useWebSocket && ws && wsConnected) {
        wsSend({ type: 'update_profile', transformId });
      } else {
        apiPost('/api/mp/update', {
          mapId: currentMapId,
          charIdx: currentCharIdx,
          transformId,
        }).catch(() => {});
      }
    },

    sendChat(text, channel) {
      if (status !== STATUS.ONLINE || !currentMapId) return;
      if (useWebSocket && ws && wsConnected) {
        wsSend({ type: 'chat', text, channel: channel || 'map' });
        return Promise.resolve({ ok: true });
      }
      return apiPost('/api/mp/chat', {
        mapId: currentMapId,
        charIdx: currentCharIdx,
        channel: channel || 'map',
        text,
      });
    },

    attackMonster(monsterId, skillId, damage) {
      if (status !== STATUS.ONLINE || !currentMapId) return;
      apiPost('/api/mp/attack', {
        mapId: currentMapId,
        charIdx: currentCharIdx,
        targetId: monsterId,
        skillId,
        damage,
      }).catch(() => {});
    },

    // 回報攻擊（對伺服器 AI 造成傷害）
    reportAttack(targetId, skillId, damage) {
      if (status !== STATUS.ONLINE || !currentMapId) return;
      const body = {
        mapId: currentMapId,
        serverId: currentServerId || 'zeus',
        charIdx: currentCharIdx,
        targetId,
        skillId: skillId || 0,
        damage: damage || 0,
      };
      // v2.7.5：優先走 WebSocket，否則走 LP
      if (useWebSocket && ws && wsConnected) {
        wsSend({ type: 'attack', ...body });
      } else {
        apiPost('/api/mp/attack', body).catch(() => {});
      }
    },

    // v2.7.9：位置上報（LP 模式下讓其他玩家看到自己移動）
    //  節流 100ms，避免過多 HTTP 請求；WS 模式下自動走 WS 通道
    _lastMoveSend: 0,
    sendPosition(x, y, dir, opts) {
      if (status !== STATUS.ONLINE || !currentMapId) return;
      const now = Date.now();
      if (now - this._lastMoveSend < 100) return; // 100ms 節流（10Hz）
      this._lastMoveSend = now;
      const body = {
        mapId: currentMapId,
        serverId: currentServerId || 'zeus',
        charIdx: currentCharIdx,
        x, y, dir,
        hp: opts?.hp != null ? opts.hp : undefined,
        transformId: opts?.transformId || undefined,
      };
      if (useWebSocket && ws && wsConnected) {
        wsSend({ type: 'move', ...body });
      } else {
        // LP 模式：fire and forget，非阻塞
        apiPost('/api/mp/update', body).catch(() => {});
      }
    },

    // 每幀更新遠端玩家位置（內插）
    tick(dt) {
      if (status !== STATUS.ONLINE || remotePlayers.size === 0) return;
      try { updateRemotePlayers(dt); } catch (e) { console.error('[Multi] tick error:', e); }
    },

    getNearbyPlayerCount,
    _getRemotePlayers() { return remotePlayers; },
    _clearAll() { clearAllRemotePlayers(); },
    _getWebSocket() { return ws; },
    // v4.4.8：純WS加入地圖（給game.js onAuthReady調用，雙保險）
    requestAutoJoin() { try { _wsAutoJoinWhenReady(); return true; } catch(e) { return false; } },
    joinMapViaWs() { try { return _wsJoinMapPure(); } catch(e) { return false; } },
    get isWebSocket() { return useWebSocket; },
    get wsFailureReason() { return _wsFailureReason; },
    getWsFailureReason: getWsFailureReason,
  };

  // ========== v2.7.2：WebSocket 連線（優先通道，失敗降級 long-poll） ==========
   function wsSend(msg) {
     if (!ws || ws.readyState !== 1) return false;
     try {
       ws.send(JSON.stringify(msg));
       return true;
     } catch(e) { return false; }
   }

   // v3.1.2：WS 連線 + 重試邏輯（模組級函數，health 成功或失敗都會呼叫）
   function _startWsWithRetry() {
     if (typeof WebSocket === 'undefined') {
       startPollLoop();
       return;
     }
     let wsRetryCount = 0;
     const MAX_WS_RETRIES = 3;
     _updateWsBadge('connecting', 'WS連線中');
     function tryWsWithRetry() {
       return tryWebSocket().catch(e => {
         wsRetryCount++;
         console.warn('[GAME-WS] 第', wsRetryCount, '次連線失敗:', e.message);
         if (wsRetryCount < MAX_WS_RETRIES) {
           const delay = 1000 * wsRetryCount;
           console.warn('[GAME-WS] ', delay, 'ms 後重試 WS (剩餘', MAX_WS_RETRIES - wsRetryCount, '次)');
           _updateWsBadge('reconnecting', 'WS重試' + wsRetryCount);
           return new Promise(function(resolve) { setTimeout(resolve, delay); })
             .then(tryWsWithRetry);
         } else {
           console.warn('[GAME-WS] WS 連線失敗已達', MAX_WS_RETRIES, '次，降級 long-poll');
           _wsFailureReason = e.message || 'WS 連線失敗';
           useWebSocket = false;
           _updateWsBadge('offline', 'WS離線');
           if (typeof window.addLog === 'function') {
             try {
               window.addLog('system', '⚠️ WebSocket 連線失敗（已重試' + MAX_WS_RETRIES + '次），已切換為輪詢模式。錯誤：' + (e.message || '未知'));
             } catch(_) {}
           }
           startPollLoop();
         }
       });
     }
     tryWsWithRetry().catch(function() { /* 最終失敗也不中斷連線流程 */ });
   }

   function tryWebSocket() {
      _manualClose = false; _forcedBackToLogin = false; // v4.4.12 新連線重置斷線標誌
     return new Promise((resolve, reject) => {
       if (typeof WebSocket === 'undefined') {
         _wsFailureReason = '瀏覽器不支援 WebSocket';
         reject(new Error(_wsFailureReason));
         return;
       }
        // v3.1.2：修復 DO 子路徑部署下 WS URL 錯誤 — 永遠用 origin root
        //  原因：Node server 監聽在根路徑 /，upgrade handler 不區分 path
        //  之前用 pathname 導致 wss://host/subpath/，upgrade 請求被 DO proxy 導到靜態檔伺服器
        //  正確方式：wss:// + host + / (與頁面 origin 同源的根)
        let wsUrl;
        try {
          const pageProto = (typeof window !== 'undefined' && window.location && window.location.protocol) || 'http:';
          const pageHost = (typeof window !== 'undefined' && window.location && window.location.host) || '';
          const pagePath = (typeof window !== 'undefined' && window.location && window.location.pathname) || '/';
          const wsProto = pageProto === 'https:' ? 'wss:' : 'ws:';
          // v3.1.2：直接用根路徑 /，避免子路徑部署下 upgrade 失敗
          wsUrl = wsProto + '//' + pageHost + '/';
          // v4.4.16：完整 token 放 URL query（走 HTTP Upgrade，不受 WS 單幀 126 位元組截斷限制），
          // 服務端在 upgrade 階段用簽名「無狀態預認證」，根治進程內 token 快取 miss 導致的靜默逾時。
          try {
            const _fullToken = authToken || '';
            let _acctForQ = '';
            try { if (typeof AuthSystem !== 'undefined' && AuthSystem.getAccount) _acctForQ = AuthSystem.getAccount() || ''; } catch (e) {}
            const _qp = [];
            if (_fullToken) _qp.push('t=' + encodeURIComponent(_fullToken));
            if (_acctForQ) _qp.push('a=' + encodeURIComponent(_acctForQ));
            if (_qp.length) wsUrl += '?' + _qp.join('&');
          } catch (e) { console.warn('[GAME-WS] query token 構建異常:', e.message); }
          console.log('[GAME-WS] ========== WebSocket 連線開始 ==========');
       _wsDebugLog('開始連線 WS URL=' + wsUrl);
          console.log('[GAME-WS] 頁面 URL =', window.location.href);
          console.log('[GAME-WS]   proto=', pageProto, 'host=', pageHost, 'pathname=', pagePath);
          console.log('[GAME-WS]   serverUrl(origin)=', serverUrl);
          console.log('[GAME-WS]   WS URL =', wsUrl);
          console.log('[GAME-WS]   authToken 長度=', authToken ? authToken.length : 0, 'token 前6字=', authToken ? authToken.substring(0,6)+'...' : '空');
       } catch(e) {
         // fallback：serverUrl 直接換協議
         wsUrl = (serverUrl || '').replace(/^http/, 'ws').replace(/\/?$/, '/');
         console.warn('[GAME-WS] URL 構建異常，使用 fallback:', wsUrl, e.message);
       }
       _wsFailureReason = '';
       try {
         ws = new WebSocket(wsUrl);
         console.log('[GAME-WS] WebSocket 物件已建立, readyState=', ws.readyState, '(0=CONNECTING)');
       } catch(e) {
         _wsFailureReason = '建立失敗: ' + (e.message || String(e));
         console.error('[GAME-WS] ❌ new WebSocket() 丟出異常:', e.message, e);
         _updateWsBadge('error', 'WS異常');
         reject(e);
         return;
       }

      let resolved = false;
      const timeout = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          reject(new Error('WebSocket 連線逾時'));
        }
      }, 5000);

       ws.onopen = () => {
         console.log('[GAME-WS] ✅ onopen - upgrade 成功, readyState=', ws.readyState, '(1=OPEN)。發送 auth...');
         _wsDebugLog('✅ WS握手成功，發送auth');
         _updateWsBadge('connecting', 'WS驗證中');
         // v4.4.3：使用 shortToken + account，整個auth消息<126位元組，避免被DO proxy截斷
         // 完整token約117位元組，加上其他字段會超過126，被DO proxy截斷導致WS錯誤
         let authAccount = '';
         try {
           if (typeof AuthSystem !== 'undefined' && AuthSystem.getAccount) {
             authAccount = AuthSystem.getAccount() || '';
           }
         } catch(e) {}
         const shortToken = authToken ? authToken.substring(0, 30) : '';
         // v4.4.5：極簡auth消息 — 只發送shortToken和account，約85位元組，絕對不會被DO proxy截斷
         // name/classId/level留到join_map時再發送
         const authMsg = {
           type: 'auth',
           shortToken: shortToken,
           account: authAccount,
         };
         const msgSize = JSON.stringify(authMsg).length;
         const authJson = JSON.stringify(authMsg);
         console.log('[GAME-WS] 已發送 auth (極簡模式), shortToken長度=', shortToken.length, 'account=', authAccount, '消息大小=', msgSize, '位元組');
         console.log('[GAME-WS] auth消息內容:', authJson);
         _wsDebugLog('📤 發送auth shortToken=' + shortToken.substring(0, 10) + '... account=' + authAccount + ' 大小=' + msgSize + 'B');
         _wsDebugLog('📤 auth內容=' + authJson);
         if (msgSize > 100) {
           console.warn('[GAME-WS] ⚠️ auth消息超過100位元組！');
           _wsDebugLog('⚠️ auth消息超過100位元組！');
         }
         if (!authAccount) {
           _wsDebugLog('❌ authAccount為空，shortToken驗證一定會失敗！');
         }
         if (!shortToken) {
           _wsDebugLog('❌ shortToken為空，authToken可能不存在！');
         }
         wsSend(authMsg);
       };

       ws.onerror = (event) => {
         console.error('[GAME-WS] ❌ onerror 觸發');
         _wsDebugLog('❌ WS onerror (readyState=' + (ws?.readyState ?? '?') + ')');
         console.error('[GAME-WS]   event.type=', event.type);
         console.error('[GAME-WS]   event.target.url=', event.target?.url || 'n/a');
         console.error('[GAME-WS]   readyState=', ws?.readyState);
         _updateWsBadge('error', 'WS錯誤');
         _wsFailureReason = 'onerror 觸發 (詳見 console)';
        if (!resolved) {
          resolved = true;
          clearTimeout(timeout);
          reject(new Error('WebSocket 連線錯誤 (onerror, readyState=' + (ws?.readyState ?? '?') + ')'));
        }
      };

       ws.onclose = (event) => {
         console.warn('[GAME-WS] ⚠️ onclose 觸發');
         console.warn('[GAME-WS]   code=', event.code);
         console.warn('[GAME-WS]   reason=', event.reason || '(空)');
         console.warn('[GAME-WS]   wasClean=', event.wasClean);
         console.warn('[GAME-WS]   readyState=', ws?.readyState);
         console.warn('[GAME-WS]   URL=', wsUrl);
         wsConnected = false;
        _wsLastCloseCode = event.code;
        _wsLastCloseReason = event.reason || '';
        if (!resolved) {
          resolved = true;
          clearTimeout(timeout);
          let reason = '連線被關閉';
          if (event.code === 1006) reason = '無法連接伺服器（code 1006，代理/防火牆可能不支援 WS Upgrade）';
          else if (event.code === 1000) reason = '正常關閉';
          else if (event.code === 1001) reason = '遠端離開（code 1001 Going Away）';
          else if (event.code === 4001) reason = '認證失敗（code 4001，token 無效）';
          else reason = '關閉 code=' + event.code + (event.reason ? '：' + event.reason : '');
          _wsFailureReason = reason;
          reject(new Error(reason));
          return;
        }
        // v4.4.12：已在線後意外斷線——嚴禁離線/降級/自動重連，立即回登入頁
        if (status === STATUS.ONLINE) {
          let _rs = '連線被關閉 code=' + (event.code || '?');
          if (event.code === 1006) _rs = '網路中斷或伺服器無回應（1006）';
          else if (event.code === 4001) _rs = '登入驗證失效，請重新登入（4001）';
          else if (event.code === 1000) _rs = '被伺服器登出（可能於其他裝置登入）';
          _forceBackToLogin(_rs);
        }
      };

      ws.onmessage = (ev) => {
        let msg;
        const rawData = typeof ev.data === 'string' ? ev.data : '';
        try { msg = JSON.parse(ev.data); } catch(e) {
          _wsDebugLog('❌ WS消息JSON解析失敗: ' + e.message + ' 原始=' + rawData.substring(0, 80));
          return;
        }
        if (!msg) return;

        // v4.4.8：分片重組（伺服器 sendJson 對≥100字節消息分片，每片50字符）
        if (msg.t === '__c') {
          const cid = msg.c, idx = msg.i, total = msg.n, part = msg.d || '';
          let buf = clientChunkBuffers.get(cid);
          if (!buf) { buf = { parts: new Map(), total: total, received: 0 }; clientChunkBuffers.set(cid, buf); }
          if (!buf.parts.has(idx)) { buf.parts.set(idx, part); buf.received++; }
          if (buf.received >= buf.total) {
            let full = '';
            for (let i = 0; i < buf.total; i++) full += buf.parts.get(i) || '';
            clientChunkBuffers.delete(cid);
            try { msg = JSON.parse(full); } catch(e) {
              _wsDebugLog('❌ 分片重組後JSON失敗 cid=' + cid + ': ' + e.message);
              return;
            }
            _wsDebugLog('🧩 分片重組完成 cid=' + cid + ' fullLen=' + full.length + ' type=' + msg.type);
          } else {
            return; // 還沒收齊，等待後續分片
          }
        }

        const rawData2 = JSON.stringify(msg);
        _wsDebugLog('📥 收到 type=' + msg.type + ' len=' + rawData2.length);
        if (!msg.type) {
          _wsDebugLog('⚠️ WS消息缺少type字段');
          return;
        }

         if (msg.type === 'auth_ok') {
           if (!resolved) {
             resolved = true;
             console.log('[GAME-WS] ✅ auth_ok - 驗證通過, clientId=', msg.id, 'account=', msg.account);
             _wsDebugLog('✅ auth成功 account=' + msg.account);
             clearTimeout(timeout);
             useWebSocket = true;
             wsConnected = true;
             wsReconnectDelay = 1000;
             console.log('[GAME-WS] 認證成功，WebSocket 模式啟用');
             setStatus(STATUS.ONLINE);
             _updateWsBadge('online', 'WS在線');
             _wsDebugLog('✅ auth成功 account=' + msg.account + '，啟動自動join');
             // v4.4.8：純WS自動join（等待GS.player就緒，不依賴HTTP/數據庫）
             _wsAutoJoinWhenReady();
             resolve(msg);
           }
           // 若已經在地圖中，重新 join
           if (currentMapId && myPlayerId) {
             wsSend({
               type: 'join_map',
               serverId: currentServerId,
               mapId: currentMapId,
               playerId: myPlayerId,
               name: window.GS?.player?.name || 'Player',
               classId: window.GS?.player?.classId || 'warrior',
               level: window.GS?.player?.level || 1,
               charIdx: currentCharIdx,
               x: window.GS?.player?.x,
               y: window.GS?.player?.y,
               hp: window.GS?.player?.hp,
               maxHp: window.GS?.player?.hpMax,
               mp: window.GS?.player?.mp,
               maxMp: window.GS?.player?.mpMax,
               nation: window.GS?.player?.nation || '',
             });
             console.log('[GAME-WS] auth_ok 後自動 join_map, mapId=' + currentMapId + ', playerId=' + myPlayerId);
           }
           return;
         } else if (msg.type === 'auth_fail') {
           console.error('[GAME-WS] ❌ auth_fail - token 驗證失敗, reason=', msg.reason || msg.error || '未知');
           _wsDebugLog('❌ auth失敗: ' + (msg.reason || msg.error || '未知'));
           clearTimeout(timeout);
           _wsFailureReason = 'auth 失敗: ' + (msg.reason || msg.error || 'token 無效');
           _updateWsBadge('error', 'WS驗證失敗');
           // v3.1.2：auth 失敗時顯示明確提示給玩家
           if (typeof window.addLog === 'function') {
             try { window.addLog('system', '⚠️ 伺服器驗證失敗：' + (msg.reason || msg.error || 'token 無效')); } catch(e) {}
           }
           if (!resolved) {
             resolved = true;
             reject(new Error(_wsFailureReason));
           }
           return;
         }

        // 其他事件走統一處理
        handleWsMessage(msg);
      };
    });
  }

  function scheduleWsReconnect() {
    if (wsReconnectTimer) return;
    wsReconnectDelay = Math.min(wsReconnectDelay * 2, 15000);
    wsReconnectTimer = setTimeout(() => {
      wsReconnectTimer = null;
      if (status !== STATUS.ONLINE && status !== STATUS.RECONNECTING) return;
      console.log('[WS] 🔄 第', (wsReconnectCount || 0) + 1, '次重連 (delay=' + wsReconnectDelay + 'ms)');
      wsReconnectCount = (wsReconnectCount || 0) + 1;
      tryWebSocket().then(() => {
        wsReconnectDelay = 1000;
        _wsFailureReason = '';
        console.log('[WS] 重連成功');
        // 重新加入地圖
        if (currentMapId && myPlayerId) {
          wsSend({
            type: 'join_map',
            serverId: currentServerId,
            mapId: currentMapId,
            playerId: myPlayerId,
            name: window.GS?.player?.name || 'Player',
            classId: window.GS?.player?.classId || 'warrior',
            level: window.GS?.player?.level || 1,
            charIdx: currentCharIdx,
          });
        }
      }).catch(e => {
        console.warn('[WS] 重連失敗:', e.message);
        // v2.7.7：保留最後失敗原因給指示器
        _wsFailureReason = e.message || '重連失敗';
        scheduleWsReconnect();
      });
    }, wsReconnectDelay);
  }

  function handleWsMessage(msg) {
    switch (msg.type) {
      // v3.0.0：Server Authoritative AOI 事件
      case 'join_map_ok':
        console.log('[WS] ✅ join_map_ok - 伺服器確認加入地圖, AOI半徑=', msg.aoiRadius, '初始實體數=', msg.entities?.length || 0);
        // v4.4.8：確認本地狀態（純WS join 成功）
        if (msg.playerId) myPlayerId = msg.playerId;
        if (msg.mapId) currentMapId = msg.mapId;
        if (msg.serverId) currentServerId = msg.serverId;
        setStatus(STATUS.ONLINE);
        _wsDebugLog('✅ join_map_ok map=' + msg.mapId + ' player=' + msg.playerId + ' 實體數=' + (msg.entities?.length || 0));
        _updateWsBadge('online', 'WS在線');
        // 設定自己的伺服器端位置
        if (msg.self && typeof window.setServerSelfState === 'function') {
          window.setServerSelfState(msg.self);
        }
        // 初始 AOI 實體
        if (msg.entities && Array.isArray(msg.entities) && typeof window.handleAOIEnter === 'function') {
          window.handleAOIEnter(msg.entities);
        }
        if (msg.aoiRadius && typeof window.setAOIRadius === 'function') {
          window.setAOIRadius(msg.aoiRadius);
        }
        break;
      case 'aoi_enter':
        if (msg.entities && Array.isArray(msg.entities) && typeof window.handleAOIEnter === 'function') {
          window.handleAOIEnter(msg.entities);
        }
        break;
      case 'aoi_update':
        if (msg.entities && Array.isArray(msg.entities) && typeof window.handleAOIUpdate === 'function') {
          window.handleAOIUpdate(msg.entities);
        }
        break;
      case 'aoi_leave':
        if (msg.ids && Array.isArray(msg.ids) && typeof window.handleAOILeave === 'function') {
          window.handleAOILeave(msg.ids);
        }
        break;
      // v3.1.0：Zone Server 地圖切換事件
      case 'map_change':
        console.log('[WS] 🗺️ map_change - 從', msg.fromMap, '到', msg.targetMap, '實體數=', msg.entities?.length || 0);
        // 通知 game.js 切換地圖
        if (typeof window.handleMapChange === 'function') {
          window.handleMapChange(msg);
        }
        break;
      case 'change_map_fail':
        console.warn('[WS] 切換地圖失敗:', msg.error, '(target:', msg.targetMap, ')');
        break;
      case 'player_join':
        if (msg.playerId !== myPlayerId) {
          addOrUpdateRemotePlayer({
            id: msg.playerId,
            name: msg.name,
            class: msg.classId,
            level: msg.level,
            x: msg.x, y: msg.y, dir: msg.dir,
            transform: msg.transformId,
          });
        }
        break;
      case 'player_leave':
        if (msg.playerId !== myPlayerId) {
          removeRemotePlayer(msg.playerId);
        }
        break;
      case 'player_move':
        if (msg.playerId !== myPlayerId) {
          handlePlayerMove({
            id: msg.playerId,
            x: msg.x, y: msg.y, dir: msg.dir,
            moving: true,
          });
        }
        break;
      case 'player_profile':
        if (msg.playerId !== myPlayerId) {
          const p = remotePlayers.get(msg.playerId);
          if (p) {
            if (msg.name != null) p.name = msg.name;
            if (msg.level != null) p.level = msg.level;
            if (msg.transformId != null) p.transform = msg.transformId;
          }
        }
        break;
      case 'map_state':
        // 進入地圖時的初始狀態（WS 通道，包含 WS+LP 玩家快照）
        if (msg.players && Array.isArray(msg.players)) {
          handlePlayerSnapshot(msg.players);
        }
        // v2.7.2：同步伺服器級 AI
        if (msg.ais && Array.isArray(msg.ais) && typeof window.setServerAIs === 'function') {
          window.setServerAIs(msg.ais, msg.serverId, msg.mapId);
        }
        break;
      case 'ai_snapshot':
      case 'ai_update':
        if (msg.ais && Array.isArray(msg.ais) && typeof window.setServerAIs === 'function') {
          window.setServerAIs(msg.ais, msg.serverId, msg.mapId);
        }
        break;
      // v2.7.5：伺服器 AI 戰鬥事件
      case 'ai_damaged':
      case 'ai_killed':
      case 'ai_attack':
      case 'ai_respawn':
        if (typeof window._handleServerAIEvent === 'function') {
          try { window._handleServerAIEvent(msg.type, msg); } catch(e) { console.warn('[WS] AI event error:', e); }
        }
        break;
      case 'chat':
        if (onChatMessage && msg.playerId !== myPlayerId) {
          try {
            onChatMessage({
              name: msg.name,
              text: msg.text,
              channel: msg.channel || 'map',
              playerId: msg.playerId,
            });
          } catch(e) {}
        }
        break;
      case 'gm_broadcast':
        if (onChatMessage) {
          try {
            onChatMessage({
              name: '【系統公告】',
              text: msg.text || '',
              channel: 'system',
              system: true,
            });
          } catch(e) {}
        }
        break;
      case 'pong':
        break;
      default:
        break;
    }
  }

  // v2.8.0：LP 自適應輪詢間隔（閒置拉長、有事件快輪）
  let _lpPollInterval = 50;     // 當前 poll 間隔
  const LP_POLL_MIN = 50;       // 最快 50ms（有事件時）
  const LP_POLL_MAX = 2000;     // 最慢 2s（完全閒置）
  const LP_POLL_IDLE_STEPS = 5; // 連續 N 次空回應才拉長
  let _lpIdleCount = 0;

  function adjustPollInterval(hasEvents) {
    if (hasEvents) {
      // 有事件：回到最快
      _lpIdleCount = 0;
      _lpPollInterval = LP_POLL_MIN;
    } else {
      _lpIdleCount++;
      if (_lpIdleCount >= LP_POLL_IDLE_STEPS) {
        // 閒置太久：逐漸拉長
        _lpPollInterval = Math.min(LP_POLL_MAX, _lpPollInterval * 1.5);
        _lpIdleCount = 0;
      }
    }
  }

  // ========== Long-Poll 循環 ==========
  function startPollLoop() {
    // v4.4.8：WS ONLY 模式，停用 long-poll（用戶明確要求只用 WebSocket）
    return;
  }

  // v4.4.8：純WS加入地圖（不依賴HTTP /api/mp/join，不依賴數據庫getCharacter）
  //  玩家資料直接從客戶端GS.player取，WS handleJoinMap 用 gameWorld.playerJoin 加入
  function _wsJoinMapPure() {
    try {
      if (!ws || ws.readyState !== 1) { _wsDebugLog('⚠️ joinPure: WS未就緒'); return false; }
      if (typeof window.GS === 'undefined' || !window.GS.player) { _wsDebugLog('⚠️ joinPure: window.GS.player不存在'); return false; }
      const mapId = window.GS.currentMap || 'village';
      let account = '';
      try { account = (typeof AuthSystem !== 'undefined' && AuthSystem.getAccount) ? (AuthSystem.getAccount() || '') : ''; } catch(e) {}
      currentCharIdx = (window.GS.currentCharIdx != null ? window.GS.currentCharIdx : (currentCharIdx || 0));
      const playerId = account + ':' + currentCharIdx;
      myPlayerId = playerId;
      currentServerId = currentServerId || 'zeus';
      // v4.4.13：角色名缺失或仍是兜底玩家/Player時，用帳號補全，避免第二帳號名字異常
      let _joinName = window.GS.player.name;
      if (!_joinName || _joinName === '玩家' || _joinName === 'Player') _joinName = account || '玩家';
      const joinMsg = {
        type: 'join_map',
        s: currentServerId, m: mapId, p: playerId,
        n: _joinName,
        c: window.GS.player.classId || 'warrior',
        l: window.GS.player.level || 1,
        charIdx: currentCharIdx,
        x: window.GS.player.x, y: window.GS.player.y,
        hp: window.GS.player.hp || 100, maxHp: window.GS.player.hpMax || window.GS.player.maxHp || 100,
        mp: window.GS.player.mp || 80, maxMp: window.GS.player.mpMax || window.GS.player.maxMp || 80,
        nation: window.GS.player.nation || (typeof window.GS !== 'undefined' ? window.GS.nation : '') || '',
      };
      const ok = wsSend(joinMsg);
      if (ok) {
        currentMapId = mapId;
        _wsDebugLog('📤 純WS join_map map=' + mapId + ' player=' + playerId);
        console.log('[GAME-WS] 純WS join_map:', mapId, playerId, 'name=', joinMsg.n, 'class=', joinMsg.c);
      } else {
        _wsDebugLog('❌ join_map發送失敗 wsSend=false');
      }
      return ok;
    } catch(e) { _wsDebugLog('❌ _wsJoinMapPure異常: ' + e.message); return false; }
  }

  // v4.4.8：等待GS.player就緒後自動join（解決connect早於onAuthReady的時序競爭，每200ms試一次，最長6秒）
  let _wsAutoJoinTimer = null, _wsAutoJoinTries = 0;
  function _wsAutoJoinWhenReady() {
    if (_wsAutoJoinTimer) { clearTimeout(_wsAutoJoinTimer); _wsAutoJoinTimer = null; }
    _wsAutoJoinTries = 0;
    const attempt = () => {
      _wsAutoJoinTries++;
      if (currentMapId && myPlayerId) { _wsDebugLog('✓ 已在地圖 ' + currentMapId + '，停止自動join'); return; }
      const gsExists = (typeof window.GS !== 'undefined' && !!window.GS);
      const hasPlayer = !!(gsExists && window.GS.player);
      const playerReady = !!(hasPlayer && window.GS.player.classId);
      const wsReady = !!(ws && ws.readyState === 1 && wsConnected);
      if (playerReady && wsReady) { _wsJoinMapPure(); return; }
      if (_wsAutoJoinTries === 1 || _wsAutoJoinTries % 5 === 0) {
        _wsDebugLog('🔄 等待就緒 第' + _wsAutoJoinTries + '次 GS=' + gsExists + ' player=' + hasPlayer + ' class=' + (hasPlayer?window.GS.player.classId:'無') + ' ws=' + wsReady);
      }
      if (_wsAutoJoinTries >= 75) { _wsDebugLog('❌ 等待玩家就緒超時15秒 GS=' + gsExists + ' player=' + hasPlayer); return; }
      _wsAutoJoinTimer = setTimeout(attempt, 200);
    };
    attempt();
  }

  function pollLoop() {
    if (status !== STATUS.ONLINE || !currentMapId) {
      pollRunning = false;
      return;
    }
    pollAbortController = new AbortController();
    const since = Date.now();
    const url = serverUrl + '/api/mp/poll?map=' + encodeURIComponent(currentMapId)
      + '&server=' + encodeURIComponent(currentServerId || 'zeus')
      + '&charIdx=' + currentCharIdx
      + '&since=' + since;

    fetch(url, {
      method: 'GET',
      headers: getAuthHeader(),
      signal: pollAbortController.signal,
      credentials: 'omit',
    })
    .then(r => r.json())
    .then(data => {
      if (data && data.ok && data.events) {
        handlePollEvents(data.events);
        // v2.8.0：處理 LP poll 返回的完整 players 快照（確保新加入/已離開玩家同步）
        if (data.players && Array.isArray(data.players)) {
          handlePlayerSnapshot(data.players);
        }
        // v2.7.3：long-poll 也推送 AI 快照（GM 調整 aiCount 時 LP 玩家同步生效）
        if (data.ais && Array.isArray(data.ais) && typeof window.setServerAIs === 'function') {
          window.setServerAIs(data.ais, currentServerId, currentMapId);
        }
        if (data.broadcasts && data.broadcasts.length) {
          // 全服廣播處理
          data.broadcasts.forEach(b => {
            if (b.type === 'gm_broadcast' && onChatMessage) {
              try {
                onChatMessage({
                  name: '【系統公告】',
                  text: b.text || '',
                  channel: 'system',
                  system: true,
                });
              } catch(e) {}
            }
          });
        }
      }
       reconnectDelay = 1000; // 重置退避
        // v2.8.0：自適應輪詢 — 有事件則快輪，空回應則逐步拉長
        const hasEvents = data.events && data.events.length > 0;
        adjustPollInterval(hasEvents);
        // 繼續下一輪
        if (pollRunning) setTimeout(pollLoop, _lpPollInterval);
    })
    .catch(err => {
      if (err.name === 'AbortError') {
        pollRunning = false;
        return;
      }
      console.warn('[Multi] poll 失敗:', err.message);
      // 退避重連
      if (pollRunning) {
        if (status === STATUS.ONLINE) setStatus(STATUS.RECONNECTING);
        setTimeout(pollLoop, reconnectDelay);
        reconnectDelay = Math.min(reconnectDelay * 2, 8000);
      }
    });
  }

  function handlePollEvents(events) {
    if (!events || !events.length) return;
    for (const ev of events) {
      if (!ev || !ev.type) continue;
      switch (ev.type) {
        case 'join':
          if (ev.playerId !== myPlayerId && ev.state) {
            addOrUpdateRemotePlayer({
              id: ev.playerId,
              name: ev.state.name,
              class: ev.state.classId,
              level: ev.state.level,
              x: ev.state.x, y: ev.state.y, dir: ev.state.dir,
              transform: ev.state.transformId,
            });
          }
          break;
        case 'leave':
          if (ev.playerId !== myPlayerId) {
            removeRemotePlayer(ev.playerId);
          }
          break;
        case 'move':
          if (ev.playerId !== myPlayerId) {
            handlePlayerMove({
              id: ev.playerId,
              x: ev.x, y: ev.y, dir: ev.dir,
              hp: ev.hp, transform: ev.transformId,
              moving: true,
            });
          }
          break;
        case 'chat':
          if (onChatMessage) {
            try {
              onChatMessage({
                name: ev.name || '匿名',
                text: ev.text || '',
                channel: ev.channel || 'map',
                country: null,
              });
            } catch(e) {}
          }
          break;
        case 'attack':
          if (ev.playerId !== myPlayerId) {
            // 觸發遠端玩家攻擊動畫
            const p = remotePlayers.get(ev.playerId);
            if (p && p.el) {
              p.el.classList.add('attacking');
              setTimeout(() => { if (p.el) p.el.classList.remove('attacking'); }, 300);
            }
            // 怪物傷害回調
            if (onMonsterDamage && ev.targetId) {
              const wPos = { x: ev.x || 0, y: ev.y || 0 };
              try {
                onMonsterDamage({
                  monsterId: ev.targetId,
                  damage: ev.damage || 0,
                  isCrit: false,
                  x: wPos.x,
                  y: wPos.y,
                  attackerName: '',
                });
              } catch(e) {}
            }
          }
          break;
        // v2.7.5：伺服器 AI 戰鬥事件（LP 通道）
        case 'ai_damaged':
        case 'ai_killed':
        case 'ai_attack':
        case 'ai_respawn':
          if (typeof window._handleServerAIEvent === 'function') {
            try { window._handleServerAIEvent(ev.type, ev); } catch(e) {}
          }
          break;
      }
    }
  }

  // ========== 工具：清空遠端玩家 ==========
  // v2.8.0：處理完整 players 快照（LP poll 返回或 WS map_state 返回）
  //  用快照做為真相：新增、更新、移除不在快照中的玩家
  function handlePlayerSnapshot(players) {
    if (!players || !Array.isArray(players)) return;
    const seen = new Set();
    players.forEach(p => {
      if (!p || !p.playerId) return;
      if (p.playerId === myPlayerId) return;
      seen.add(p.playerId);
      addOrUpdateRemotePlayer({
        id: p.playerId,
        name: p.name,
        class: p.classId,
        level: p.level,
        x: p.x, y: p.y, dir: p.dir,
        transform: p.transformId,
        country: p.nation,
      });
    });
    // 移除不在快照中的玩家
    for (const id of remotePlayers.keys()) {
      if (!seen.has(id)) removeRemotePlayer(id);
    }
  }

  // v2.8.0：取得附近玩家數（給 UI 顯示「附近玩家:N」）
  function getNearbyPlayerCount() {
    let n = 0;
    for (const p of remotePlayers.values()) {
      if (p.el && !p.isBot) n++;
    }
    return n;
  }

  function handleMapState(entities, monsters) {
    const seen = new Set();
    entities.forEach(ent => {
      if (!ent || !ent.id) return;
      if (ent.id === mySocketId) return;
      seen.add(ent.id);
      addOrUpdateRemotePlayer(ent);
    });
    for (const id of remotePlayers.keys()) {
      if (!seen.has(id)) removeRemotePlayer(id);
    }
  }

  function handlePlayerMove(data) {
    if (data.id === mySocketId) return;
    let p = remotePlayers.get(data.id);
    if (!p) {
      p = createRemotePlayer({ id: data.id, x: data.x, y: data.y, dir: data.dir });
      remotePlayers.set(data.id, p);
    }
    const wPos = serverToWorld(data.x || 0, data.y || 0);
    p.targetX = wPos.x;
    p.targetY = wPos.y;
    p.dir = (data.dir === -1 || data.dir === 1) ? data.dir : (data.dir || 1);
    p.moving = !!data.moving;
    p.lastMoveAt = Date.now();
    // v4.4.14：真正顯示遠端玩家的是 game.js 的 AOI 實體，player_move 即時刷新其插值目標（serverToWorld 為恆等，用原始座標）
    try { if (typeof window._aoiMoveTarget === 'function') window._aoiMoveTarget(data.id, data.x, data.y, data.dir); } catch (e) {}
  }

  function addOrUpdateRemotePlayer(ent) {
    if (ent.id === mySocketId) return;
    let p = remotePlayers.get(ent.id);
    const wPos = serverToWorld(ent.x || 0, ent.y || 0);
    if (!p) {
      p = createRemotePlayer(ent, wPos);
      remotePlayers.set(ent.id, p);
    } else {
      if (ent.name != null) p.name = ent.name;
      if (ent.class != null) p.classId = ent.class;
      if (ent.level != null) p.level = ent.level;
      if (ent.transform != null) p.transformId = ent.transform;
      if (ent.country != null) p.nation = ent.country;
      if (ent.x != null) { p.targetX = wPos.x; p.x = wPos.x; }
      if (ent.y != null) { p.targetY = wPos.y; p.y = wPos.y; }
      if (ent.dir != null) p.dir = ent.dir;
      p.moving = !!ent.moving;
      p.isBot = !!ent.isBot;
      p.lastMoveAt = Date.now();
    }
    if (!p.el) buildRemotePlayerDOM(p);
    else refreshRemotePlayerVisual(p);
    return p;
  }

  function createRemotePlayer(ent, wPos) {
    const pos = wPos || { x: 0, y: 0 };
    return {
      id: ent.id,
      name: ent.name || 'Player',
      classId: ent.class || 'warrior',
      level: ent.level || 1,
      transformId: ent.transform || null,
      nation: ent.country || null,
      x: pos.x,
      y: pos.y,
      targetX: pos.x,
      targetY: pos.y,
      dir: (ent.dir === -1 || ent.dir === 1) ? ent.dir : 1,
      moving: !!ent.moving,
      isBot: !!ent.isBot,
      el: null,
      lastMoveAt: Date.now(),
      _wasWalking: false,
    };
  }

  function removeRemotePlayer(id) {
    const p = remotePlayers.get(id);
    if (!p) return;
    if (p.el && p.el.parentNode) p.el.remove();
    remotePlayers.delete(id);
  }

  function clearAllRemotePlayers() {
    for (const id of remotePlayers.keys()) {
      const p = remotePlayers.get(id);
      if (p && p.el && p.el.parentNode) p.el.remove();
    }
    remotePlayers.clear();
  }

  // ========== 渲染（使用現有 window.SPRITE 圖資、8幀動畫） ==========
  function getSpriteForRemote(p) {
    if (typeof window.SPRITE === 'undefined') return null;
    if (p.transformId) {
      const key = String(p.transformId).replace(/^tf_/, '').replace(/^t_/, '');
      if (window.SPRITE[key]) return window.SPRITE[key];
      if (window.SPRITE['t_' + key]) return window.SPRITE['t_' + key];
    }
    if (window.SPRITE[p.classId]) return window.SPRITE[p.classId];
    return window.SPRITE.warrior || null;
  }

  // v4.4.0：伺服器端AI渲染
  function addOrUpdateServerAI(aiData) {
    try {
      const aiId = aiData.id;
      let ai = serverAIs.get(aiId);
      if (!ai) {
        ai = {
          id: aiId,
          name: aiData.name || 'Monster',
          level: aiData.level || 1,
          x: aiData.x || 0,
          y: aiData.y || 0,
          hp: aiData.hp || 100,
          maxHp: aiData.maxHp || 100,
          nation: aiData.nation || '',
          state: aiData.state || 'idle',
          classId: aiData.classId || 'enemy',
          el: null,
          _hpFill: null,
        };
        buildServerAIDOM(ai);
        serverAIs.set(aiId, ai);
      }
      ai.x = aiData.x != null ? aiData.x : ai.x;
      ai.y = aiData.y != null ? aiData.y : ai.y;
      ai.hp = aiData.hp != null ? aiData.hp : ai.hp;
      ai.maxHp = aiData.maxHp != null ? aiData.maxHp : ai.maxHp;
      ai.name = aiData.name || ai.name;
      ai.level = aiData.level || ai.level;
      ai.state = aiData.state || ai.state;
      if (ai._hpFill && ai.maxHp) {
        ai._hpFill.style.width = Math.max(0, (ai.hp / ai.maxHp) * 100) + '%';
      }
    } catch(e) { console.error('[ServerAI] addOrUpdate error:', e); }
  }
  
  function buildServerAIDOM(ai) {
    if (typeof document === 'undefined') return;
    const worldLayer = document.getElementById('world-layer');
    if (!worldLayer) return;
    try {
      const elDiv = document.createElement('div');
      elDiv.className = 'world-unit ai-player mp-server-ai idle';
      elDiv.dataset.id = 'mp_ai_' + ai.id.replace(/:/g, '_');
      elDiv.dataset.remoteId = ai.id;
      
      const s = (typeof window.SPRITE !== 'undefined') ? (window.SPRITE[ai.classId] || window.SPRITE.enemy || window.SPRITE.warrior || null) : null;
      const isImg = !!(s && s.useImg);
      const glow = s?.glow || '#ff6060';
      const filter = `drop-shadow(0 0 4px ${glow}) drop-shadow(0 2px 3px rgba(0,0,0,0.8))`;
      const w = 50, h = 56;
      
      elDiv.innerHTML = `
        <div class="unit-info">
          <div class="unit-hp-bar"><div class="unit-hp-fill" style="width:100%;background:#ff5050"></div></div>
          <div class="unit-name" style="color:#ff8080;font-size:9px">${escapeHtml(ai.name)} Lv.${ai.level}</div>
        </div>
        <div class="unit-sprite-wrap" style="width:${w}px;height:${h}px;">
          ${isImg ? `<img class="unit-sprite-img sprite-frame-idle" src="${s.idle}" style="filter:${filter}" alt="" loading="lazy"/>` : `<div class="unit-sprite-emoji" style="font-size:36px;">👹</div>`}
        </div>
        <div class="unit-shadow"></div>
      `;
      
      worldLayer.appendChild(elDiv);
      ai.el = elDiv;
      ai._hpFill = elDiv.querySelector('.unit-hp-fill');
      
      if (typeof window.positionUnit === 'function') {
        try { window.positionUnit(elDiv, ai.x, ai.y, 'enemy'); } catch(e) {}
      } else {
        elDiv.style.left = (ai.x - w/2) + 'px';
        elDiv.style.bottom = ai.y + 'px';
      }
    } catch(e) { console.error('[ServerAI] buildDOM error:', e); }
  }

  function buildRemotePlayerDOM(p) {
    if (typeof document === 'undefined') return;
    const worldLayer = document.getElementById('world-layer');
    if (!worldLayer) return;

    const elDiv = document.createElement('div');
    elDiv.className = 'world-unit remote-player mp-player idle';
    elDiv.dataset.id = 'mp_' + p.id;
    elDiv.dataset.remoteId = p.id;
    elDiv.dataset.mpId = p.id;

    const s = getSpriteForRemote(p);
    const isImg = !!(s && s.useImg);
    const glow = s?.glow || '#ffe090';
    const filter = `drop-shadow(0 0 4px ${glow}) drop-shadow(0 2px 3px rgba(0,0,0,0.8))`;

    // 國家敵我判定
    const myNation = (typeof window.GS !== 'undefined') ? (window.GS.nation || null) : null;
    const isEnemy = p.nation && myNation && p.nation !== myNation;
    if (isEnemy) elDiv.classList.add('enemy-ai');

    const nameColor = isEnemy ? '#ff8080' : '#80d0ff';
    const hpColor = isEnemy ? '#ff5050' : '#50c8ff';

    // 國旗
    let flagImg = '';
    if (typeof window.NATIONS !== 'undefined' && typeof window.safeFlagImg === 'function' && p.nation) {
      const n = window.NATIONS.find(nn => nn.id === p.nation);
      if (n) flagImg = window.safeFlagImg(p.nation, 12);
    }

    const w = 64, h = 80;
    const coverMode = s?.coverMode ? 'sprite-cover-mode' : '';
    const multiFrame = s?.multiFrame ? 'sprite-multi-frame' : '';

    const onErrorStr = (typeof window.handleImgError === 'function')
      ? 'window.handleImgError(this)'
      : '';

    let walkImgs = '';
    if (isImg && s.walk) {
      walkImgs += `<img class="unit-sprite-img sprite-frame-walk sprite-frame-walk-1" src="${s.walk}" style="filter:${filter};display:none" alt="" onerror="${onErrorStr}"/>`;
      if (s.walk2) walkImgs += `<img class="unit-sprite-img sprite-frame-walk sprite-frame-walk-2" src="${s.walk2}" style="filter:${filter};display:none" alt="" onerror="${onErrorStr}"/>`;
      if (s.walk3) walkImgs += `<img class="unit-sprite-img sprite-frame-walk sprite-frame-walk-3" src="${s.walk3}" style="filter:${filter};display:none" alt="" onerror="${onErrorStr}"/>`;
      if (s.walk4) walkImgs += `<img class="unit-sprite-img sprite-frame-walk sprite-frame-walk-4" src="${s.walk4}" style="filter:${filter};display:none" alt="" onerror="${onErrorStr}"/>`;
    }

    elDiv.innerHTML = `
      <div class="unit-info">
        <div class="unit-hp-bar"><div class="unit-hp-fill" style="width:100%;background:${hpColor}"></div></div>
        <div class="unit-name" style="color:${nameColor};font-size:10px;display:flex;align-items:center;justify-content:center;gap:2px">${flagImg}<span>${escapeHtml(p.name)}</span></div>
        <div class="unit-level-tag" style="display:none">Lv.${p.level}</div>
      </div>
      <div class="unit-sprite-wrap ${coverMode} ${multiFrame}" style="width:${w}px;height:${h}px;background:radial-gradient(ellipse at 50% 70%, rgba(100,70,40,0.25), transparent 70%);">
        ${isImg ? `
          <img class="unit-sprite-img sprite-frame-idle" src="${s.idle}" style="filter:${filter}" alt="" loading="lazy" onerror="${onErrorStr}"/>
          ${walkImgs}
          <div class="unit-sprite-tomb" style="display:none"></div>
          <div class="dust-particles"></div>
        ` : `
          <div class="unit-sprite-emoji" style="color:${s?.color || '#c0a060'};font-size:52px;filter:${filter}">&#9876;</div>
        `}
      </div>
      <div class="unit-shadow"></div>
    `;

    worldLayer.appendChild(elDiv);
    p.el = elDiv;

    if (typeof window.initUnitAnimState === 'function') {
      try { window.initUnitAnimState('mp_' + p.id); } catch (e) { /* ignore */ }
    }
    if (typeof window.positionUnit === 'function') {
      try { window.positionUnit(elDiv, p.x, p.y, 'hero'); } catch (e) { /* ignore */ }
    } else {
      elDiv.style.left = (p.x - w / 2) + 'px';
      elDiv.style.bottom = p.y + 'px';
    }
    if (p.dir === -1) elDiv.classList.add('face-left');
  }

  function refreshRemotePlayerVisual(p) {
    if (!p.el) return;
    if (p.el.parentNode) {
      p.el.remove();
      p.el = null;
    }
    buildRemotePlayerDOM(p);
  }

  // ========== 每幀內插 ==========
  function updateRemotePlayers(dt) {
    if (remotePlayers.size === 0 && serverAIs.size === 0) return;
    const lerpFactor = 1 - Math.pow(0.001, dt);

    for (const p of remotePlayers.values()) {
      if (!p.el) continue;

      const dx = p.targetX - p.x;
      const dy = p.targetY - p.y;
      const dist = Math.hypot(dx, dy);

      if (dist > 0.5) {
        p.x += dx * lerpFactor;
        p.y += dy * lerpFactor;
        if (Math.abs(dx) > 1) {
          const newDir = dx > 0 ? 1 : -1;
          if (newDir !== p.dir) {
            p.dir = newDir;
            p.el.classList.toggle('face-left', p.dir === -1);
          }
        }
        if (dist > 4 && !p._wasWalking) {
          p.el.classList.remove('idle');
          p.el.classList.add('walking');
          p._wasWalking = true;
        }
      } else {
        if (p._wasWalking) {
          p.el.classList.remove('walking');
          p.el.classList.add('idle');
          p._wasWalking = false;
        }
      }

      if (typeof window.positionUnit === 'function') {
        try { window.positionUnit(p.el, p.x, p.y, 'hero'); } catch (e) { /* ignore */ }
      } else {
        p.el.style.left = (p.x - 32) + 'px';
        p.el.style.bottom = p.y + 'px';
      }

      if (typeof window.applyUnitAnimFrame === 'function') {
        try {
          const state = p._wasWalking ? 'walking' : 'idle';
          window.applyUnitAnimFrame(p.el, 'mp_' + p.id, state);
        } catch (e) { /* ignore */ }
      }
    }
    
    // v4.4.0：更新伺服器AI位置
    for (const ai of serverAIs.values()) {
      if (!ai.el) continue;
      if (typeof window.positionUnit === 'function') {
        try { window.positionUnit(ai.el, ai.x, ai.y, 'enemy'); } catch(e) {}
      } else {
        ai.el.style.left = (ai.x - 25) + 'px';
        ai.el.style.bottom = ai.y + 'px';
      }
      if (ai._hpFill && ai.maxHp) {
        ai._hpFill.style.width = Math.max(0, (ai.hp / ai.maxHp) * 100) + '%';
      }
    }
  }

   // v3.1.2：遊戲畫面左上角 WS 狀態標籤（肉眼可見，不只在 console）
   let _wsBadgeEl = null;
   // v4.4.3：遊戲內調試面板（手機用戶不用F12，點擊左上角WS標籤即可查看）
   let _wsDebugPanel = null;
   let _wsDebugVisible = false;
   const _wsDebugLogs = [];
   function _wsDebugLog(msg) {
     const entry = new Date().toLocaleTimeString() + ' ' + msg;
     _wsDebugLogs.push(entry);
     if (_wsDebugLogs.length > 50) _wsDebugLogs.shift();
     if (_wsDebugPanel && _wsDebugVisible) _updateWsDebugPanel();
   }
   function _toggleWsDebug() {
     if (!_wsDebugPanel) _createWsDebugPanel();
     _wsDebugVisible = !_wsDebugVisible;
     _wsDebugPanel.style.display = _wsDebugVisible ? 'block' : 'none';
     if (_wsDebugVisible) _updateWsDebugPanel();
   }
   function _createWsDebugPanel() {
     const panel = document.createElement('div');
     panel.id = 'ws-debug-panel';
     panel.style.cssText = 'position:fixed;top:30px;left:6px;z-index:99998;width:280px;max-height:60vh;overflow-y:auto;background:rgba(0,0,0,0.92);color:#0f0;font-size:10px;font-family:monospace;padding:8px;border-radius:6px;border:1px solid #444;display:none;';
     panel.innerHTML = '<div style="color:#ffd93d;margin-bottom:4px;">📡 WS 調試面板（點擊WS標籤關閉）</div><div id="ws-debug-content"></div>';
     document.body.appendChild(panel);
     _wsDebugPanel = panel;
   }
   function _updateWsDebugPanel() {
     if (!_wsDebugPanel) return;
     const contentEl = _wsDebugPanel.querySelector('#ws-debug-content');
     if (!contentEl) return;
     const info = [
       '狀態: ' + (status === 'online' ? '在線' : status === 'connecting' ? '連線中' : status === 'reconnecting' ? '重連中' : status === 'error' ? '錯誤' : '離線'),
       'WS已連線: ' + wsConnected,
       '使用WS: ' + useWebSocket,
       '伺服器: ' + serverUrl,
       '地圖: ' + (currentMapId || '無'),
       '我的ID: ' + (myPlayerId || '無'),
       '遠端玩家: ' + remotePlayers.size,
       '失敗原因: ' + (_wsFailureReason || '無'),
       '--- 最近日誌 ---',
     ];
     for (let i = Math.max(0, _wsDebugLogs.length - 20); i < _wsDebugLogs.length; i++) {
       info.push(_wsDebugLogs[i]);
     }
     contentEl.innerHTML = info.join('<br>');
   }
   function _ensureWsBadge() {
     if (_wsBadgeEl) return;
     try {
       const badge = document.createElement('div');
       badge.id = 'ws-status-badge';
       badge.style.cssText = 'position:fixed;top:6px;left:6px;z-index:99999;padding:2px 6px;font-size:10px;font-family:monospace;border-radius:3px;pointer-events:auto;cursor:pointer;opacity:0.9;user-select:none;';
       badge.textContent = 'WS離線';
       badge.style.background = '#333';
       badge.style.color = '#aaa';
       badge.title = '點擊查看WS調試信息';
       badge.addEventListener('click', _toggleWsDebug);
       document.body.appendChild(badge);
       _wsBadgeEl = badge;
       _wsDebugLog('調試面板就緒，點擊左上角WS標籤查看詳情');
     } catch(e) {}
   }
   function _updateWsBadge(state, label) {
     _ensureWsBadge();
     if (!_wsBadgeEl) return;
     _wsBadgeEl.textContent = label || 'WS';
     const colors = {
       online:    { bg: '#1a4d2e', color: '#4ecdc4' },
       connecting:{ bg: '#3d3d1a', color: '#ffd93d' },
       error:     { bg: '#4d1a1a', color: '#ff6b6b' },
       offline:   { bg: '#333',    color: '#aaa' },
       reconnecting: { bg: '#3d3d1a', color: '#ffd93d' },
     };
     const c = colors[state] || colors.offline;
     _wsBadgeEl.style.background = c.bg;
     _wsBadgeEl.style.color = c.color;
   }

   // ========== 暴露到全域 ==========
  window.MultiplayerClient = MultiplayerClient;

  // 頁面關閉/刷新前主動斷線
  if (typeof window !== 'undefined') {
    window.addEventListener('beforeunload', () => {
      try { MultiplayerClient.disconnect(); } catch (e) { /* ignore */ }
    });
  }
})();
